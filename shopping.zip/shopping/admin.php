<?=template_header('Admin')?>
<?php

 $stmt = $pdo->prepare("SELECT * FROM contact");

 $stmt->execute();

 $result = $stmt->fetchAll();

 $table = "
    <table class='table table-hover'>
    <tr>
        <th>Namn</th>
        <th>telefon</th>
        <th>Email</th>
    </tr>
    ";

 foreach($result as $key => $value){

    $id = $value['id']; 

    $table .= "
        <tr>
        <td>$value[name]</td>    
        <td>$value[tel]</td>
        <td>$value[email]</td>
        </tr>
    ";
 }

 $table .= "</table>";

 echo $table;
 ?>
 <hr size="8" width="90%" color="red"> 
