<?php 
template_header('cart');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<pre>";
    //print_r($_POST);
    echo "</pre>";

    $name = $_POST['name'];
    $tel = $_POST['tel'];
    $email = $_POST['email'];
    $address = $_POST['address'];


    $stmt = $pdo->prepare("INSERT INTO customers (name, tel, email, address)
                                VALUES (:name , :tel, :email, :address)");

    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':tel', $tel);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':address', $address);


    $stmt->execute();


    $last_id = $pdo->lastInsertId();

    $message = "<div class='alert alert-success' role='alert'>
                    <p> Tack för din order $name.</p>
                </div>";

}

?>


<?php

if(isset($message)) echo $message;
?>


 <?=template_footer()?>
